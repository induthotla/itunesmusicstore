export const SEARCHURL = "https://itunes.apple.com/search?term=";
export const ARTISTSEARCHURL = "https://itunes.apple.com/lookup?id=";